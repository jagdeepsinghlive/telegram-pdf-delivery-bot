# Telegram PDF Delivery Bot

Cloudflare Worker + Telegram Bot + Supabase.

## Repository structure

telegram-pdf-delivery-bot/
├── src/
│   └── index.js
├── wrangler.jsonc
├── .gitignore
└── README.md

## Required Cloudflare Secrets

Set these in Cloudflare Worker Secrets. Do NOT put them in GitHub:

- BOT_TOKEN
- SUPABASE_URL
- SUPABASE_KEY
- ADMIN_TELEGRAM_ID
- WEBHOOK_SECRET
- CHANNEL_ID
- CHANNEL_INVITE_URL

## Deployment

Connect this repository to Cloudflare Workers and deploy.

## Database

The Supabase database must already contain the required tables and the
`cleanup_expired_data()` RPC function described in the setup instructions.

## Important

`SUPABASE_KEY` must be the server-side/service-role key and must remain
private inside Cloudflare. Never commit it to GitHub.

Paid-product payment processing is not included in this package yet.
